<?php
	
	
			$conectar = mysqli_connect("localhost","root","","Agenda")or die("Ha Ocurrido un Error ");
		

 ?>